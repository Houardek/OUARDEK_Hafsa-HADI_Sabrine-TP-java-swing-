import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Casse-briques neon : Java Swing et Java2D, sans dependances. */
public class NeonBreaker extends JPanel {
    static final int W=600,H=820,LEFT=65,RIGHT=535,TOP=110,BOTTOM=755;
    static final Color GREEN=new Color(100,255,0);
    final Random random=new Random();
    final ArrayList<Brick> bricks=new ArrayList<>();
    final ArrayList<Particle> particles=new ArrayList<>();
    final ArrayList<Point2D.Double> trail=new ArrayList<>();
    final Set<Integer> keys=new HashSet<>();
    double x,y,vx,vy,paddle=300; int score,lives=3,level=1,combo=0;
    boolean launched=false,paused=false,gameOver=false; long last=System.nanoTime();
    final javax.swing.Timer timer;
    static class Brick {double x,y; boolean alive=true; Brick(double a,double b){x=a;y=b;}}
    static class Particle {double x,y,vx,vy,life,max; Particle(double a,double b,double dx,double dy,double l){x=a;y=b;vx=dx;vy=dy;life=max=l;}}
    NeonBreaker(boolean running){
        setPreferredSize(new Dimension(W,H));setBackground(Color.BLACK);setFocusable(true);
        reset();
        addMouseMotionListener(new MouseMotionAdapter(){public void mouseMoved(MouseEvent e){paddle=clamp(e.getX(),LEFT+44,RIGHT-44);}public void mouseDragged(MouseEvent e){mouseMoved(e);}});
        addMouseListener(new MouseAdapter(){public void mousePressed(MouseEvent e){requestFocusInWindow();launch();}});
        bind("LEFT",KeyEvent.VK_LEFT);bind("RIGHT",KeyEvent.VK_RIGHT);bind("A",KeyEvent.VK_A);bind("D",KeyEvent.VK_D);
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("SPACE"),"launch");getActionMap().put("launch",new AbstractAction(){public void actionPerformed(ActionEvent e){launch();}});
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("P"),"pause");getActionMap().put("pause",new AbstractAction(){public void actionPerformed(ActionEvent e){if(!gameOver){paused=!paused;last=System.nanoTime();repaint();}}});
        getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("R"),"reset");getActionMap().put("reset",new AbstractAction(){public void actionPerformed(ActionEvent e){reset();}});
        timer=new javax.swing.Timer(16,e->{long now=System.nanoTime();double dt=Math.min(.04,(now-last)/1e9);last=now;update(dt);repaint();});if(running)timer.start();
    }
    void bind(String name,int code){getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("pressed "+name),name+"down");getInputMap(WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("released "+name),name+"up");getActionMap().put(name+"down",new AbstractAction(){public void actionPerformed(ActionEvent e){keys.add(code);}});getActionMap().put(name+"up",new AbstractAction(){public void actionPerformed(ActionEvent e){keys.remove(code);}});}
    static double clamp(double a,double lo,double hi){return Math.max(lo,Math.min(hi,a));}
    void reset(){score=0;lives=3;level=1;combo=0;gameOver=false;paused=false;paddle=300;particles.clear();keys.clear();makeBricks();serve();last=System.nanoTime();repaint();}
    void makeBricks(){bricks.clear();for(int row=0;row<5;row++)for(int col=0;col<10;col++)bricks.add(new Brick(82+col*44,148+row*43));}
    void serve(){launched=false;x=paddle;y=693;vx=160;vy=-320;trail.clear();combo=0;}
    void launch(){if(gameOver){reset();return;}if(!paused)launched=true;}
    void explode(Brick b){b.alive=false;score+=100+(Math.min(combo,10)*20);combo++;for(int i=0;i<28;i++){double a=random.nextDouble()*Math.PI*2,speed=55+random.nextDouble()*230;particles.add(new Particle(b.x+17,b.y+17,Math.cos(a)*speed,Math.sin(a)*speed,.35+random.nextDouble()*.55));}}
    void update(double dt){
        if(paused||gameOver)return;
        if(keys.contains(KeyEvent.VK_LEFT)||keys.contains(KeyEvent.VK_A))paddle-=480*dt;
        if(keys.contains(KeyEvent.VK_RIGHT)||keys.contains(KeyEvent.VK_D))paddle+=480*dt;
        paddle=clamp(paddle,LEFT+44,RIGHT-44);
        for(Iterator<Particle> it=particles.iterator();it.hasNext();){Particle p=it.next();p.life-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=130*dt;if(p.life<=0)it.remove();}
        if(!launched){x=paddle;y=693;return;}
        trail.add(new Point2D.Double(x,y));if(trail.size()>15)trail.remove(0);
        // Petits sous-pas : evite de traverser les carres a grande vitesse.
        int steps=Math.max(1,(int)Math.ceil(Math.hypot(vx,vy)*dt/4));
        for(int i=0;i<steps;i++){
            double oldX=x,oldY=y;x+=vx*dt/steps;y+=vy*dt/steps;
            if(x<LEFT+7){x=LEFT+7;vx=Math.abs(vx);}if(x>RIGHT-7){x=RIGHT-7;vx=-Math.abs(vx);}if(y<TOP+7){y=TOP+7;vy=Math.abs(vy);}
            if(vy>0&&oldY+7<=716&&y+7>=716&&x>=paddle-49&&x<=paddle+49){y=709;double speed=Math.min(560,Math.hypot(vx,vy)+5),angle=clamp((x-paddle)/44,-1,1)*1.05;vx=Math.sin(angle)*speed;vy=-Math.cos(angle)*speed;combo=0;}
            for(Brick b:bricks)if(b.alive&&x+7>b.x&&x-7<b.x+34&&y+7>b.y&&y-7<b.y+34){
                if(oldY+7<=b.y){y=b.y-7;vy=-Math.abs(vy);}else if(oldY-7>=b.y+34){y=b.y+41;vy=Math.abs(vy);}else if(oldX+7<=b.x){x=b.x-7;vx=-Math.abs(vx);}else{x=b.x+41;vx=Math.abs(vx);}explode(b);break;
            }
            if(y>BOTTOM+18){lives--;if(lives<=0)gameOver=true;else serve();return;}
        }
        boolean remaining=false;for(Brick b:bricks)if(b.alive){remaining=true;break;}
        if(!remaining){level++;makeBricks();serve();}
    }
    static void text(Graphics2D g,String s,int x,int y,int size,Color c){g.setFont(new Font("SansSerif",Font.BOLD,size));g.setColor(c);g.drawString(s,x,y);}
    void centered(Graphics2D g,String s,int y,int size,Color c){g.setFont(new Font("SansSerif",Font.BOLD,size));g.setColor(c);g.drawString(s,(W-g.getFontMetrics().stringWidth(s))/2,y);}
    void glowLine(Graphics2D g,double x1,double y1,double x2,double y2,Color color){for(int k=12;k>=2;k-=2){g.setStroke(new BasicStroke(k));g.setColor(new Color(color.getRed(),color.getGreen(),color.getBlue(),12));g.draw(new Line2D.Double(x1,y1,x2,y2));}g.setColor(color);g.setStroke(new BasicStroke(1.3f));g.draw(new Line2D.Double(x1,y1,x2,y2));}
    protected void paintComponent(Graphics graphics){
        super.paintComponent(graphics);Graphics2D g=(Graphics2D)graphics.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        g.setPaint(new GradientPaint(0,0,new Color(3,9,4),0,H,new Color(0,0,0)));g.fillRect(0,0,W,H);
        for(int xx=LEFT+10;xx<RIGHT;xx+=10)for(int yy=TOP+10;yy<BOTTOM;yy+=10){int a=(int)(20+22*Math.sin(xx*.11+yy*.05));g.setColor(new Color(80,200,0,Math.max(8,a)));g.fillRect(xx,yy,2,3);}
        text(g,"NEON",LEFT,48,27,GREEN);text(g,"BREAKER",LEFT+91,48,27,Color.WHITE);
        text(g,String.format("SCORE  %06d",score),LEFT,79,12,new Color(175,190,175));
        text(g,"LEVEL  "+level,285,79,12,new Color(175,190,175));
        for(int i=0;i<3;i++){g.setColor(i<lives?GREEN:new Color(35,55,30));g.fillOval(480+i*17,68,8,8);}
        glowLine(g,LEFT,TOP,RIGHT,TOP,GREEN);glowLine(g,LEFT,TOP,LEFT,BOTTOM,GREEN);glowLine(g,RIGHT,TOP,RIGHT,BOTTOM,GREEN);
        for(Brick b:bricks)if(b.alive){for(int k=10;k>=2;k-=2){g.setColor(new Color(100,255,0,7));g.fillRoundRect((int)b.x-k/2,(int)b.y-k/2,34+k,34+k,5,5);}g.setColor(new Color(24,65,8));g.fillRoundRect((int)b.x,(int)b.y,34,34,3,3);g.setColor(GREEN);g.setStroke(new BasicStroke(1.3f));g.drawRoundRect((int)b.x,(int)b.y,34,34,3,3);g.setColor(new Color(165,255,85));g.fillRect((int)b.x+5,(int)b.y+5,5,3);}
        for(Particle p:particles){float alpha=(float)Math.max(0,p.life/p.max);g.setColor(new Color(.45f,1f,.06f,alpha));double size=2+alpha*4;g.fill(new Rectangle2D.Double(p.x,p.y,size,size));}
        for(int i=0;i<trail.size();i++){Point2D.Double t=trail.get(i);float a=(i+1f)/trail.size();g.setColor(new Color(1f,1f,1f,a*.4f));double r=2+a*4;g.fill(new Ellipse2D.Double(t.x-r,t.y-r,r*2,r*2));}
        for(int k=20;k>=4;k-=4){g.setColor(new Color(255,255,255,9));g.fill(new Ellipse2D.Double(x-7-k/2,y-7-k/2,14+k,14+k));}g.setColor(Color.WHITE);g.fill(new Ellipse2D.Double(x-7,y-7,14,14));
        for(int k=18;k>=2;k-=2){g.setColor(new Color(90,255,0,10));g.fillRoundRect((int)paddle-44-k/2,716-k/2,88+k,10+k,18,18);}g.setColor(GREEN);g.fillRoundRect((int)paddle-44,716,88,10,10,10);g.setColor(new Color(200,255,150));g.fillRoundRect((int)paddle-30,717,60,2,3,3);
        if(!launched&&!gameOver&&!paused){centered(g,"CLIQUEZ / ESPACE POUR LANCER",455,14,Color.WHITE);centered(g,"Visez les carres. Faites-les exploser.",480,12,new Color(135,165,125));}
        if(paused||gameOver){g.setColor(new Color(0,0,0,190));g.fillRect(LEFT+1,TOP+1,RIGHT-LEFT-2,BOTTOM-TOP);centered(g,gameOver?"GAME OVER":"PAUSE",435,36,GREEN);centered(g,gameOver?"R / ESPACE : REJOUER":"P : REPRENDRE",472,13,Color.WHITE);}
        centered(g,"SOURIS / FLECHES : BOUGER    |    P : PAUSE    |    R : REJOUER",791,10,new Color(115,135,110));
        g.dispose();
    }
    static void selfTest(){NeonBreaker n=new NeonBreaker(false);Brick b=n.bricks.get(0);n.explode(b);if(b.alive||n.particles.size()!=28||n.score!=100)throw new AssertionError("explosion");n.reset();n.launched=true;n.x=LEFT+7;n.y=450;n.vx=-200;n.vy=0;n.update(.02);if(n.vx<=0)throw new AssertionError("wall");n.x=n.paddle;n.y=708;n.vx=0;n.vy=300;n.update(.02);if(n.vy>=0)throw new AssertionError("paddle");n.reset();Brick target=n.bricks.get(0);n.launched=true;n.x=target.x+17;n.y=target.y+43;n.vx=0;n.vy=-300;n.update(.02);if(target.alive||n.vy<=0)throw new AssertionError("brick collision");n.reset();n.launched=true;n.y=BOTTOM+40;n.update(.01);if(n.lives!=2||n.launched)throw new AssertionError("life");n.paused=true;double old=n.x;n.update(.03);if(n.x!=old)throw new AssertionError("pause");System.out.println("PASS: explosion, wall, paddle, brick collision, lives, pause");}
    public static void main(String[] args)throws Exception{
        if(args.length>0&&args[0].equals("--test")){selfTest();return;}
        if(args.length>0&&args[0].equals("--preview")){NeonBreaker p=new NeonBreaker(false);p.setSize(W,H);p.launched=true;p.x=225;p.y=530;p.explode(p.bricks.get(24));for(Particle q:p.particles){q.x+=q.vx*.15;q.y+=q.vy*.15;}BufferedImage image=new BufferedImage(W,H,BufferedImage.TYPE_INT_RGB);Graphics2D g=image.createGraphics();p.paint(g);g.dispose();ImageIO.write(image,"png",new File(args[1]));return;}
        SwingUtilities.invokeLater(()->{JFrame f=new JFrame("NEON BREAKER | Java Swing");NeonBreaker game=new NeonBreaker(true);f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);f.setContentPane(game);f.pack();f.setResizable(false);f.setLocationRelativeTo(null);f.setVisible(true);game.requestFocusInWindow();});
    }
}

