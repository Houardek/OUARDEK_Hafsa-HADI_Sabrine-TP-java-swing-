@echo off
cd /d "%~dp0"
if not exist classes mkdir classes
javac -encoding UTF-8 -source 8 -target 8 -d classes src\PaintSwing.java
if errorlevel 1 goto fail
copy /Y src\*.properties classes\ >nul
jar cfe PaintSwing.jar PaintSwing -C classes .
if errorlevel 1 goto fail
echo Compilation terminee.
pause
exit /b 0
:fail
echo Echec de compilation. Verifier que le JDK est installe.
pause
exit /b 1
