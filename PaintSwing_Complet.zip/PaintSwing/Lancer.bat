@echo off
cd /d "%~dp0"
java -jar PaintSwing.jar
if errorlevel 1 pause
