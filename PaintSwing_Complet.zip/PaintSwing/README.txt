PAINT SWING — Application de dessin internationalisee

EXECUTER
Installer Java 8 ou plus recent puis lancer :
java -jar PaintSwing.jar
Sous Windows, vous pouvez aussi double-cliquer sur Lancer.bat.

UTILISATION
Choisir Crayon, Gomme, Ligne, Rectangle ou Ellipse puis cliquer-glisser.
Choisir la couleur, l'epaisseur (1 a 50) et le remplissage des formes.
Fichier : nouveau, ouvrir PNG/JPEG, enregistrer PNG, quitter.
Edition : annuler les 10 dernieres actions, effacer tout.
Langue : Francais / English, changement immediat sans perdre le dessin.
Le programme demande d'enregistrer les modifications avant ouverture,
nouveau dessin ou fermeture. La gomme peint en blanc.
La feuille initiale mesure 1000 x 600 pixels. Une image ouverte garde sa taille.

CODE SOURCE
src/PaintSwing.java : interface Swing, dessin Java2D et gestion des fichiers.
src/Messages*.properties : traductions via ResourceBundle et Locale.
Aucune dependance externe. Pas de JavaFX requis.

RECOMPILER (JDK 8 ou plus recent)
Executer Compiler.bat, puis Lancer.bat.
Le JAR fourni est compile pour Java 8.

VERIFICATION
Compilation Java 8 et test automatique des ressources FR/EN,
du dessin Java2D et de l'encodage PNG effectues.
Le comportement visuel et les interactions sont a verifier en lancant le JAR.

VERSION RUBAN
Interface inspiree de Paint : ruban, palette, feuille centree, reglage lateral.
Outils ajoutes : pinceau, pipette, texte, triangle, losange et fleche.
Le pinceau trace un trait continu. Zoom fixe a 100 pour cent.
Les fonctions selection, calques et Copilot ne sont pas implementees.
