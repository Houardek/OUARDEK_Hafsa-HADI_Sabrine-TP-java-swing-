import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import javax.imageio.ImageIO;

/** Application de dessin Swing, sans bibliotheque externe. */
public class PaintSwing extends JFrame {
    private ResourceBundle messages;
    private Locale locale = Locale.FRENCH;
    private final Canvas canvas = new Canvas();
    private Color color = Color.BLACK;
    private String tool = "pencil";
    private int thickness = 4;
    private boolean filled = false;
    private boolean dirty = false;
    private JLabel statusLabel;
    private final Color accent = new Color(91,83,238);
    private final Map<String, AbstractButton> labels = new LinkedHashMap<>();
    private final java.util.List<JMenu> menus = new ArrayList<>();

    public PaintSwing() {
        super("Paint Swing");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                if (confirmDiscard()) dispose();
            }
        });
        JPanel paper = new JPanel(new GridBagLayout()) {
            protected void paintComponent(Graphics graphics){super.paintComponent(graphics);Graphics2D g=(Graphics2D)graphics.create();g.setColor(new Color(216,220,232));for(int x=18;x<getWidth();x+=24)for(int y=18;y<getHeight();y+=24)g.fillOval(x,y,2,2);g.dispose();}
        };
        paper.setBackground(new Color(239,241,248));
        paper.setBorder(BorderFactory.createEmptyBorder(28,65,45,65));
        canvas.setBorder(BorderFactory.createLineBorder(new Color(210,213,218)));
        JPanel sheet=new JPanel(new BorderLayout());sheet.setOpaque(false);
        sheet.setBorder(new javax.swing.border.AbstractBorder(){
            public Insets getBorderInsets(Component c){return new Insets(12,12,22,22);}
            public void paintBorder(Component c,Graphics graphics,int x,int y,int w,int h){Graphics2D g=(Graphics2D)graphics.create();for(int i=16;i>0;i--){g.setColor(new Color(35,45,80,2));g.fillRoundRect(x+12-i/2,y+15-i/2,w-24+i,h-30+i,12,12);}g.dispose();}
        });sheet.add(canvas);paper.add(sheet);
        JScrollPane scroll = new JScrollPane(paper);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        add(scroll, BorderLayout.CENTER);
        buildInterface();
        canvas.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
        JRootPane root=getRootPane();
        String[] shortcuts={"control S","control O","control Z"};
        Runnable[] actions={()->save(),()->open(),()->canvas.undo()};
        for(int i=0;i<shortcuts.length;i++){final Runnable action=actions[i];root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke(shortcuts[i]),shortcuts[i]);root.getActionMap().put(shortcuts[i],new AbstractAction(){public void actionPerformed(ActionEvent e){action.run();}});}
        setSize(1380, 900);
        setLocationRelativeTo(null);
    }
    private String tr(String key) { return messages.getString(key); }
    private void bind(AbstractButton b, String key) { labels.put(key, b); }
    private JMenuItem item(JMenu menu, String key, Runnable action) {
        JMenuItem i = new JMenuItem(); bind(i,key);
        i.addActionListener(e -> action.run()); menu.add(i); return i;
    }
    private void buildInterface() {
        messages = ResourceBundle.getBundle("Messages",locale);
        labels.clear(); menus.clear();
        JMenuBar bar = new JMenuBar();
        bar.setBackground(Color.WHITE);bar.setBorder(BorderFactory.createEmptyBorder(7,20,7,20));
        JLabel brand=new JLabel("  P  /  PAINT STUDIO     ");brand.setFont(new Font("SansSerif",Font.BOLD,16));brand.setForeground(accent);bar.add(brand);
        JMenu file = new JMenu(); bind(file,"file"); bar.add(file);
        item(file,"new",() -> { if(confirmDiscard()) {canvas.remember(); canvas.blank(); dirty=false;} });
        item(file,"open",this::open);
        item(file,"save",() -> save());
        file.addSeparator();
        item(file,"exit",() -> dispatchEvent(new WindowEvent(this,WindowEvent.WINDOW_CLOSING)));
        JMenu edit = new JMenu(); bind(edit,"edit"); bar.add(edit);
        item(edit,"undo",() -> canvas.undo());
        item(edit,"clear",() -> {if(JOptionPane.showConfirmDialog(this,tr("clearQuestion"),tr("clear"),JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION){canvas.remember();canvas.blank();dirty=true;}});
        JMenu language = new JMenu(); bind(language,"language"); bar.add(language);
        JMenuItem fr = new JMenuItem("Français"), en = new JMenuItem("English");
        language.add(fr);language.add(en);
        fr.addActionListener(e -> changeLanguage(Locale.FRENCH));
        en.addActionListener(e -> changeLanguage(Locale.ENGLISH));
        JMenu help = new JMenu();bind(help,"help");bar.add(help);
        item(help,"about",() -> JOptionPane.showMessageDialog(this,tr("aboutText"),tr("about"),JOptionPane.INFORMATION_MESSAGE));
        bar.add(Box.createHorizontalGlue());
        JLabel badge=new JLabel("JAVA SWING   /   "+(locale.getLanguage().equals("fr")?"FR":"EN")+"   ");badge.setForeground(new Color(125,130,151));badge.setFont(new Font("SansSerif",Font.BOLD,10));bar.add(badge);
        setJMenuBar(bar);
        JPanel toolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        toolbar.setBackground(Color.WHITE);
        toolbar.setBorder(BorderFactory.createMatteBorder(0,0,1,0,new Color(221,224,228)));
        JPanel imageGroup = group("image");
        JButton openButton = ribbonButton("open", "open");
        openButton.setText(locale.getLanguage().equals("fr")?"Ouvrir":"Open");openButton.addActionListener(e -> open());imageGroup.add(openButton);
        JButton saveButton = ribbonButton("save", "save");
        saveButton.setText("PNG");saveButton.addActionListener(e -> save());imageGroup.add(saveButton);
        imageGroup.setPreferredSize(new Dimension(190,78));toolbar.add(imageGroup.getParent());
        ButtonGroup tools = new ButtonGroup();
        JPanel toolGroup = group("tools");
        for(String key : new String[]{"pencil","eraser","picker","text"}) {
            toolGroup.add(toolButton(key,tools));
        }
        toolGroup.setPreferredSize(new Dimension(150,78));toolbar.add(toolGroup.getParent());
        JPanel brushGroup = group("brushes");brushGroup.add(toolButton("brush",tools));toolbar.add(brushGroup.getParent());
        JPanel shapes = group("shapes");
        for(String key : new String[]{"line","rectangle","ellipse","triangle","diamond","arrow"})shapes.add(toolButton(key,tools));
        JCheckBox fill = new JCheckBox(tr("fill"));fill.setOpaque(false);fill.setSelected(filled);
        fill.addActionListener(e -> filled=fill.isSelected());shapes.add(fill);
        shapes.setPreferredSize(new Dimension(250,78));toolbar.add(shapes.getParent());
        JPanel colors = group("colors");
        JPanel palette = new JPanel(new GridLayout(2,10,5,6));palette.setOpaque(false);
        Color[] swatches={new Color(31,37,56),new Color(110,110,110),new Color(140,20,40),Color.RED,new Color(255,130,30),new Color(255,215,0),new Color(30,170,80),new Color(0,165,220),new Color(60,70,200),new Color(155,65,175),Color.WHITE,new Color(200,200,200),new Color(180,120,80),new Color(255,170,195),new Color(255,210,130),new Color(245,240,180),new Color(170,220,80),new Color(150,215,230),new Color(125,155,195),new Color(205,180,220)};
        for(Color c:swatches){JButton swatch=new JButton(new ColorIcon(c));swatch.setPreferredSize(new Dimension(25,25));swatch.setBorderPainted(false);swatch.setContentAreaFilled(false);swatch.setFocusPainted(false);swatch.setToolTipText(String.format("#%06X",c.getRGB()&0xffffff));swatch.addActionListener(e->{color=c;repaint();});palette.add(swatch);}
        colors.add(palette);
        JButton choose=ribbonButton("color","color");choose.addActionListener(e->{Color c=JColorChooser.showDialog(this,tr("color"),color);if(c!=null){color=c;repaint();}});colors.add(choose);
        colors.setPreferredSize(new Dimension(375,78));toolbar.add(colors.getParent());
        Component old = ((BorderLayout)getContentPane().getLayout()).getLayoutComponent(BorderLayout.NORTH);
        if(old!=null)remove(old);
        JPanel north=new JPanel(new BorderLayout());north.setBackground(Color.WHITE);
        JPanel titleRow=new JPanel(new BorderLayout());titleRow.setBackground(Color.WHITE);titleRow.setBorder(BorderFactory.createEmptyBorder(14,24,10,24));
        JLabel heading=new JLabel(locale.getLanguage().equals("fr")?"Votre prochaine idée commence ici.":"Your next idea starts here.");heading.setFont(new Font("SansSerif",Font.BOLD,20));heading.setForeground(new Color(35,42,65));titleRow.add(heading,BorderLayout.WEST);
        JPanel quick=new JPanel(new FlowLayout(FlowLayout.RIGHT,8,0));quick.setOpaque(false);
        JButton undoQuick=new JButton(tr("undo"));styleButton(undoQuick);undoQuick.addActionListener(e->canvas.undo());quick.add(undoQuick);
        JButton export=new JButton(locale.getLanguage().equals("fr")?"Exporter PNG  >":"Export PNG  >");styleButton(export);export.putClientProperty("primary",Boolean.TRUE);export.setForeground(Color.WHITE);export.addActionListener(e->save());quick.add(export);
        titleRow.add(quick,BorderLayout.EAST);north.add(titleRow,BorderLayout.NORTH);north.add(toolbar,BorderLayout.CENTER);add(north,BorderLayout.NORTH);
        JPanel controls=new JPanel();controls.setLayout(new BoxLayout(controls,BoxLayout.Y_AXIS));
        controls.setBackground(new Color(239,241,248));controls.setBorder(BorderFactory.createEmptyBorder(45,17,35,10));
        JLabel widthLabel=new JLabel(tr("width"));widthLabel.setFont(new Font("SansSerif",Font.BOLD,10));widthLabel.setForeground(new Color(110,116,140));widthLabel.setAlignmentX(0.5f);controls.add(widthLabel);
        JSlider widthSlider=new JSlider(JSlider.VERTICAL,1,50,thickness);widthSlider.setOpaque(false);widthSlider.setPreferredSize(new Dimension(55,260));widthSlider.setMaximumSize(new Dimension(65,300));widthSlider.addChangeListener(e->thickness=widthSlider.getValue());controls.add(widthSlider);
        JLabel sizeValue=new JLabel(thickness+" px");sizeValue.setFont(new Font("SansSerif",Font.BOLD,12));sizeValue.setForeground(accent);sizeValue.setAlignmentX(0.5f);controls.add(sizeValue);
        widthSlider.addChangeListener(e->sizeValue.setText(widthSlider.getValue()+" px"));
        controls.add(Box.createVerticalStrut(24));
        JComponent active=new JComponent(){protected void paintComponent(Graphics graphics){Graphics2D g=(Graphics2D)graphics.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setColor(Color.WHITE);g.fillRoundRect(3,3,44,44,14,14);g.setColor(color);g.fillOval(11,11,28,28);g.setColor(new Color(210,213,225));g.drawOval(11,11,28,28);g.dispose();}};
        active.setPreferredSize(new Dimension(50,50));active.setMaximumSize(new Dimension(50,50));active.setAlignmentX(0.5f);controls.add(active);
        Component west=((BorderLayout)getContentPane().getLayout()).getLayoutComponent(BorderLayout.WEST);if(west!=null)remove(west);add(controls,BorderLayout.WEST);
        JLabel status=new JLabel();statusLabel=status;updateStatus();status.setOpaque(true);status.setBackground(Color.WHITE);status.setForeground(new Color(105,112,135));status.setFont(new Font("SansSerif",Font.PLAIN,11));
        status.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1,0,0,0,new Color(220,222,226)),BorderFactory.createEmptyBorder(8,10,8,10)));
        Component south=((BorderLayout)getContentPane().getLayout()).getLayoutComponent(BorderLayout.SOUTH);if(south!=null)remove(south);add(status,BorderLayout.SOUTH);
        for(Map.Entry<String,AbstractButton> e:labels.entrySet())e.getValue().setText(tr(e.getKey()));
        setTitle("Paint Studio | "+tr("title")); revalidate();repaint();
    }
    private JPanel group(String key){
        JPanel outer=new JPanel(new BorderLayout());outer.setOpaque(false);
        outer.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0,0,0,1,new Color(228,230,234)),BorderFactory.createEmptyBorder(10,12,10,12)));
        JPanel content=new JPanel(new FlowLayout(FlowLayout.CENTER,4,5));content.setOpaque(false);content.setPreferredSize(new Dimension(100,78));
        JLabel label=new JLabel(tr(key),SwingConstants.CENTER);label.setForeground(new Color(100,105,112));label.setFont(new Font("SansSerif",Font.BOLD,10));
        outer.add(content,BorderLayout.CENTER);outer.add(label,BorderLayout.SOUTH);return content;
    }
    private JButton ribbonButton(String label,String icon){
        JButton b=new JButton(tr(label),new ToolIcon(icon));styleButton(b);b.setToolTipText(tr(label));return b;
    }
    private JToggleButton toolButton(String key,ButtonGroup buttons){
        JToggleButton b=new JToggleButton(new ToolIcon(key));styleButton(b);b.setToolTipText(tr(key));b.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));b.setPreferredSize(new Dimension(34,34));b.setSelected(tool.equals(key));buttons.add(b);b.addActionListener(e->tool=key);return b;
    }
    private void updateStatus(){if(statusLabel!=null)statusLabel.setText("   "+canvas.image.getWidth()+" x "+canvas.image.getHeight()+" px     /     "+tr("hint")+"                                            PNG     /     100 %");}
    private void styleButton(AbstractButton b){
        b.setFont(new Font("SansSerif",Font.BOLD,11));b.setForeground(new Color(63,69,92));b.setFocusPainted(false);b.setRolloverEnabled(true);b.setOpaque(false);b.setContentAreaFilled(false);b.setBorder(BorderFactory.createEmptyBorder(8,10,8,10));b.setVerticalTextPosition(SwingConstants.BOTTOM);b.setHorizontalTextPosition(SwingConstants.CENTER);
        b.setUI(new javax.swing.plaf.basic.BasicButtonUI(){
            public void paint(Graphics graphics,JComponent component){AbstractButton button=(AbstractButton)component;Graphics2D g=(Graphics2D)graphics.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);boolean primary=Boolean.TRUE.equals(button.getClientProperty("primary"));boolean selected=button.isSelected();g.setColor(primary?accent:selected?new Color(231,228,255):button.getModel().isRollover()?new Color(239,240,250):new Color(247,248,252));g.fillRoundRect(0,0,component.getWidth()-1,component.getHeight()-1,12,12);if(selected){g.setColor(accent);g.drawRoundRect(0,0,component.getWidth()-1,component.getHeight()-1,12,12);}g.dispose();super.paint(graphics,component);}
        });
    }
    private class ColorIcon implements Icon {
        final Color c;ColorIcon(Color c){this.c=c;}public int getIconWidth(){return 23;}public int getIconHeight(){return 23;}
        public void paintIcon(Component component,Graphics graphics,int x,int y){Graphics2D g=(Graphics2D)graphics.create();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setColor(c);g.fillOval(x+2,y+2,19,19);g.setColor(new Color(175,180,195));g.drawOval(x+2,y+2,19,19);if(c.equals(color)){g.setColor(accent);g.setStroke(new BasicStroke(2));g.drawOval(x,y,23,23);}g.dispose();}
    }
    private static class ToolIcon implements Icon {
        final String key;ToolIcon(String k){key=k;}public int getIconWidth(){return 24;}public int getIconHeight(){return 24;}
        public void paintIcon(Component c,Graphics graphics,int x,int y){Graphics2D g=(Graphics2D)graphics.create();g.translate(x,y);g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setStroke(new BasicStroke(1.6f));g.setColor(new Color(45,50,58));
            if(key.equals("line"))g.drawLine(3,3,21,21);
            else if(key.equals("rectangle"))g.drawRect(3,5,18,14);
            else if(key.equals("ellipse"))g.drawOval(3,4,18,16);
            else if(key.equals("triangle"))g.drawPolygon(new int[]{12,2,22},new int[]{3,21,21},3);
            else if(key.equals("diamond"))g.drawPolygon(new int[]{12,22,12,2},new int[]{2,12,22,12},4);
            else if(key.equals("arrow"))g.drawPolygon(new int[]{2,13,13,22,13,13,2},new int[]{8,8,3,12,21,16,16},7);
            else if(key.equals("text")){g.setFont(new Font("Serif",Font.PLAIN,25));g.drawString("A",3,21);}
            else if(key.equals("eraser")){g.setColor(new Color(245,165,180));g.fillPolygon(new int[]{3,13,22,12},new int[]{14,3,12,23},4);g.setColor(Color.DARK_GRAY);g.drawPolygon(new int[]{3,13,22,12},new int[]{14,3,12,23},4);}
            else if(key.equals("color")){for(int i=0;i<12;i++){g.setColor(Color.getHSBColor(i/12f,0.85f,0.95f));g.fillArc(2,2,20,20,i*30,32);}}
            else if(key.equals("save")){g.drawRoundRect(4,2,17,20,2,2);g.drawRect(7,3,10,6);g.drawRect(7,13,11,9);}
            else if(key.equals("open")){g.setColor(new Color(240,190,65));g.fillRoundRect(2,7,21,15,3,3);g.setColor(new Color(90,100,115));g.drawRoundRect(2,7,21,15,3,3);g.drawRect(3,3,9,4);}
            else if(key.equals("brush")){g.setColor(new Color(70,145,215));g.fillRoundRect(9,2,6,13,3,3);g.setColor(new Color(90,65,45));g.fillOval(5,13,14,9);}
            else {g.setColor(key.equals("picker")?new Color(40,140,210):new Color(235,190,65));g.setStroke(new BasicStroke(5));g.drawLine(5,20,19,5);g.setColor(Color.DARK_GRAY);g.setStroke(new BasicStroke(1.5f));g.drawLine(3,22,7,20);}
            g.dispose();}
    }
    private void changeLanguage(Locale l){locale=l;buildInterface();}
    private boolean confirmDiscard(){
        if(!dirty)return true;
        int answer=JOptionPane.showConfirmDialog(this,tr("unsaved"),tr("title"),JOptionPane.YES_NO_CANCEL_OPTION);
        if(answer==JOptionPane.YES_OPTION)return save();
        return answer==JOptionPane.NO_OPTION;
    }
    private JFileChooser chooser(){
        JFileChooser f=new JFileChooser();
        f.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Images PNG / JPEG","png","jpg","jpeg"));return f;
    }
    private void error(Exception e){JOptionPane.showMessageDialog(this,tr("error")+"\n"+e.getMessage(),tr("error"),JOptionPane.ERROR_MESSAGE);}
    private void open(){
        if(!confirmDiscard())return;
        JFileChooser f=chooser();if(f.showOpenDialog(this)!=JFileChooser.APPROVE_OPTION)return;
        try{
            BufferedImage loaded=ImageIO.read(f.getSelectedFile());
            if(loaded==null)throw new IOException(tr("invalid"));
            if((long)loaded.getWidth()*loaded.getHeight()>16000000L)throw new IOException(tr("tooLarge"));
            canvas.remember();canvas.image=copy(loaded);canvas.refresh();dirty=false;
        }catch(IOException e){error(e);}
    }
    private boolean save(){
        JFileChooser f=chooser();f.setSelectedFile(new File("dessin.png"));
        if(f.showSaveDialog(this)!=JFileChooser.APPROVE_OPTION)return false;
        File target=f.getSelectedFile();
        if(!target.getName().toLowerCase(Locale.ROOT).endsWith(".png"))target=new File(target.getPath()+".png");
        if(target.exists()&&JOptionPane.showConfirmDialog(this,tr("overwrite"),tr("save"),JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return false;
        try{if(!ImageIO.write(canvas.image,"png",target))throw new IOException(tr("error"));dirty=false;return true;}
        catch(IOException e){error(e);return false;}
    }
    static BufferedImage copy(BufferedImage source){
        BufferedImage result=new BufferedImage(source.getWidth(),source.getHeight(),BufferedImage.TYPE_INT_RGB);
        Graphics2D g=result.createGraphics();g.setColor(Color.WHITE);g.fillRect(0,0,result.getWidth(),result.getHeight());g.drawImage(source,0,0,null);g.dispose();return result;
    }
    private class Canvas extends JPanel {
        BufferedImage image = new BufferedImage(1000,600,BufferedImage.TYPE_INT_RGB);
        final Deque<BufferedImage> history=new ArrayDeque<>();
        Point start,last,current; boolean dragging=false;
        Canvas(){
            blank();
            MouseAdapter mouse=new MouseAdapter(){
                public void mousePressed(MouseEvent e){
                    if(!SwingUtilities.isLeftMouseButton(e))return;
                    if(tool.equals("picker")){if(e.getX()>=0&&e.getY()>=0&&e.getX()<image.getWidth()&&e.getY()<image.getHeight())color=new Color(image.getRGB(e.getX(),e.getY()));return;}
                    if(tool.equals("text")){String text=JOptionPane.showInputDialog(PaintSwing.this,tr("textPrompt"));if(text!=null&&!text.isEmpty()){remember();Graphics2D g=image.createGraphics();setup(g);g.setFont(new Font("SansSerif",Font.PLAIN,Math.max(14,thickness*5)));g.drawString(text,e.getX(),e.getY());g.dispose();dirty=true;repaint();}return;}
                    remember();start=e.getPoint();last=start;current=start;dragging=true;
                    if(tool.equals("pencil")||tool.equals("brush")||tool.equals("eraser")){stroke(start,start);dirty=true;}repaint();
                }
                public void mouseDragged(MouseEvent e){
                    if(!dragging)return;current=e.getPoint();
                    if(tool.equals("pencil")||tool.equals("brush")||tool.equals("eraser")){stroke(last,current);last=current;dirty=true;}repaint();
                }
                public void mouseReleased(MouseEvent e){
                    if(!dragging)return;current=e.getPoint();
                    if(!tool.equals("pencil")&&!tool.equals("brush")&&!tool.equals("eraser")){Graphics2D g=image.createGraphics();shape(g);g.dispose();}
                    dragging=false;dirty=true;repaint();
                }
            };addMouseListener(mouse);addMouseMotionListener(mouse);
        }
        void blank(){Graphics2D g=image.createGraphics();g.setColor(Color.WHITE);g.fillRect(0,0,image.getWidth(),image.getHeight());g.dispose();refresh();}
        void refresh(){if(messages!=null)updateStatus();setPreferredSize(new Dimension(image.getWidth(),image.getHeight()));revalidate();repaint();}
        void remember(){if(history.size()>=10)history.removeLast();history.push(copy(image));}
        void undo(){if(!history.isEmpty()){image=history.pop();dirty=true;refresh();}}
        void setup(Graphics2D g){g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);g.setColor(color);g.setStroke(new BasicStroke(thickness,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND));}
        void stroke(Point a,Point b){Graphics2D g=image.createGraphics();setup(g);if(tool.equals("eraser"))g.setColor(Color.WHITE);g.drawLine(a.x,a.y,b.x,b.y);g.dispose();}
        void shape(Graphics2D g){
            setup(g);int x=Math.min(start.x,current.x),y=Math.min(start.y,current.y),w=Math.abs(start.x-current.x),h=Math.abs(start.y-current.y);
            if(tool.equals("line"))g.drawLine(start.x,start.y,current.x,current.y);
            else if(tool.equals("rectangle")){if(filled)g.fillRect(x,y,w,h);else g.drawRect(x,y,w,h);}
            else if(tool.equals("ellipse")){if(filled)g.fillOval(x,y,w,h);else g.drawOval(x,y,w,h);}
            else {
                Polygon p=new Polygon();
                if(tool.equals("triangle")){p.addPoint(x+w/2,y);p.addPoint(x+w,y+h);p.addPoint(x,y+h);}
                else if(tool.equals("diamond")){p.addPoint(x+w/2,y);p.addPoint(x+w,y+h/2);p.addPoint(x+w/2,y+h);p.addPoint(x,y+h/2);}
                else if(tool.equals("arrow")){p.addPoint(x,y+h/3);p.addPoint(x+w*2/3,y+h/3);p.addPoint(x+w*2/3,y);p.addPoint(x+w,y+h/2);p.addPoint(x+w*2/3,y+h);p.addPoint(x+w*2/3,y+h*2/3);p.addPoint(x,y+h*2/3);}
                if(filled)g.fillPolygon(p);else g.drawPolygon(p);
            }
        }
        protected void paintComponent(Graphics graphics){super.paintComponent(graphics);graphics.drawImage(image,0,0,null);
            if(dragging&&!tool.equals("pencil")&&!tool.equals("brush")&&!tool.equals("eraser")){Graphics2D g=(Graphics2D)graphics.create();g.clipRect(0,0,image.getWidth(),image.getHeight());shape(g);g.dispose();}}
    }
    private static void layoutTree(Container c){c.doLayout();for(Component child:c.getComponents())if(child instanceof Container)layoutTree((Container)child);}
    public static void main(String[] args){SwingUtilities.invokeLater(() -> {
        try{UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());}catch(Exception ignored){}
        UIManager.put("Menu.font",new Font("SansSerif",Font.PLAIN,12));UIManager.put("MenuItem.font",new Font("SansSerif",Font.PLAIN,12));UIManager.put("Menu.selectionBackground",new Color(231,228,255));UIManager.put("Menu.selectionForeground",new Color(60,50,160));UIManager.put("Slider.thumb",new Color(91,83,238));UIManager.put("Slider.highlight",new Color(91,83,238));UIManager.put("Slider.altTrackColor",new Color(220,223,235));UIManager.put("ToolTip.background",new Color(35,42,65));UIManager.put("ToolTip.foreground",Color.WHITE);
        PaintSwing app=new PaintSwing();
        if(args.length>0&&args[0].equals("--preview")){
            app.setSize(1380,900);app.addNotify();app.validate();app.getRootPane().setSize(1380,900);layoutTree(app.getRootPane());
            BufferedImage preview=new BufferedImage(1380,900,BufferedImage.TYPE_INT_RGB);
            Graphics2D g=preview.createGraphics();app.getRootPane().printAll(g);g.dispose();
            try{ImageIO.write(preview,"png",new File(args.length>1?args[1]:"preview.png"));}catch(IOException e){e.printStackTrace();}
            app.dispose();
        }else app.setVisible(true);
    });}
}
